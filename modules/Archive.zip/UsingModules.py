# import operations as o
# from operations import add
from operations import *

print(add(10, 20))
print(add(10, 20))
print(add(10, 20))
print(add(10, 20))
print(add(10, 20))
print(subtract(20, 10))
